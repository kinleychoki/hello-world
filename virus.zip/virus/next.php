<?php
        if(isset($_POST['submit'])){
		$username=$_POST['uname'];
		$password=md5($_POST['passwd']);
		
		//session_start();
		$query= "SELECT * FROM register WHERE username='$username' && password='password'";
		$data=mysqli_query($conn,$query);
		$total=mysqli_num_rows($data);
		echo $total;
		
		}


?>