<?php  include 'connect.php';
	$username=$_POST["uname"];
	$password=$_POST["passwd"];
	
	
	$stmt = $conn->prepare("Insert into account (email,password)
								values(?,?)");
	$stmt->bind_param("ss",$username,$password);
	
	
	$stmt->execute();
	header('location:Page2.html');
	echo"success";
	$stmt->close();
	$conn->close();
       
		   
?>   

