<style>
th{
	background:#e6ecff;
}
td{
	background:lightgrey;
}

</style>
<?php include 'connect.php';
     session_start();
	 
	 $date = $_POST["date"];
	 // echo $date;
	 $dayName = $_POST["dayName"];
	 // echo $dayName;
	 $division = $_POST["division"];
	 // echo $division;
	 $startTime = $_POST["startTime"];
	 // echo $startTime;
	 $endTime = $_POST["endTime"];
	 // echo $endTime;
	 $breakTime = $_POST["breakTime"];
	 // echo $breakTime;
	 $totalTime = $_POST["totalTime"];
	 // echo $totalTime;
	 $extraTime = $_POST["extraTime"];
	 // echo $extraTime;
	 $extraWork = $_POST["extraWork"];
	 // echo $extraWork;
	 $content = $_POST["content"];
	 // echo $content;
	 $Wrecord = $_POST["Wrecord"];
	 // echo $Wrecord;
	 
	 
	 $user_id = $_SESSION["userid"]; //$_SESSION['userid'] 
	 //echo $user_id;
	 // $user_id = 10;
	 /*$date = $_GET["date"];
	 $dayName = $_GET["dayName"];
	 $division = $_GET["division"];
	 $startTime = $_GET["startTime"];
	 $endTime = $_GET["endTime"];
	 $breakTime = $_GET["breakTime"];
	 $totalTime = $_GET["totalTime"];
	 $extraTime = $_GET["extraTime"];
	 $extraWork = $_GET["extraWork"];
	 $content = $_GET["content"];
	 $Wrecord = $_GET["Wrecord"];*/
	 
	 
	 // $stmt =$conn->prepare("INSERT INTO tabledata(date,dayName,division,startTime,endTime,breakTime,
	 // totalTime,extraTime,extraWork,content,Wrecord,user_id)
	 // VALUES(?,?,?,?,?,?,?,?,?,?,?,?)");

	$sql = "INSERT INTO tabledata(tdate,dayName,division,startTime,endTime,breakTime,
		  totalTime,extraTime,extraWork,content,Wrecord,user_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";

	if($query = $conn->prepare($sql)) { // assuming $mysqli is the connection
	    $query->bind_param("sssssssssssi",$date,$dayName,$division,$startTime,$endTime,$breakTime,$totalTime,$extraTime,$extraWork,$content,$Wrecord,$user_id);
	    $query->execute();
	    // printf("%d Row inserted.\n", $query->affected_rows);
	    // any additional code you need would go here.
	} else {
	    $error = $conn->errno . ' ' . $conn->error;
	    echo $error; // 1054 Unknown column 'foo' in 'field list'
	}

		$sql = "SELECT * FROM tabledata";//where user_id= $user_id //= $_SESSION['userid']; 
		$result = $conn->query($sql);
         // output data of each row
		
		echo "<table border='1'>
			<tr>
			<th> 日付 </th>
			<th> 曜日 </th>
			<th> 区分 </th>
			<th> 始業時刻 </th>
			<th> 終業時刻 </th>
			<th> 休憩時間 </th>
			<th> 時間内時間 </th>
			<th> 時間外時間 </th>
			<th> 休日時間 </th>
			<th> 業務内容 </th>
			<th> 勤怠 </th>
			
			</tr>";
			if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
				
			echo "<tr>
			 <td>" . $row['tdate']. "</td>
			 <td>" . $row['dayName'] . "</td>
			 <td>". $row['division']. "</td>
			 <td>" . $row['startTime'] . "</td>
			 <td>" . $row['endTime'] . "</td>
			 <td>". $row['breakTime'] . "</td>
			 <td>" .$row['totalTime'] . "</td>
			 <td>" . $row['extraTime'] . "</td>
			 <td>". $row['extraWork'] . "</td>
			 <td>" . $row['content'] . "</td>
			 <td>" . $row['Wrecord'] . "</td>
			
			<td><a href='populateData.php?id=$row[id]&date=$row[tdate]&dayName=$row[dayName]&division=$row[division]&
			 startTime=$row[startTime]&endTime=$row[endTime]&breakTime=$row[breakTime]&
			 totalTime=$row[totalTime]&extraTime=$row[extraTime]&extraWork=$row[extraWork]&
			 content=$row[content]&Wrecord=$row[Wrecord]'>EDIT</a></td>
			
			</tr>";
			}	
		echo "</table>";
		}
		 else { 
			 echo $_SESSION['userid'];
			 echo "0 results"; 
			 }
		$conn->close();
		
		

?>
    <form align="center" action="logout.php">
    <div class="input-group">
	     <br><button type="submit" class="btn" name="submit" align="center"> LOG OUT </button>
     </div>
	 </form>
	 <form align="center" action="koke.html">
	 <div class="input-group">
	       <button type="submit" class="btn" name="submit" align="center"> 集計 </button>
     </div>
     </form>