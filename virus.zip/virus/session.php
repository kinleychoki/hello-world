<?php
// Establishing Connection with Server 
include 'connect.php';
//starting session
session_start();
//storing session
//$login_username = $_SESSION['username'];
//$_SESSION['username'] = $username;

// Selecting Database
$sql = "SELECT * FROM register WHERE username = '$username' and password ='$password'";
$row=mysql_fetch_assoc($sql);
$login_username=$row['username'];
//----------------------------------------------------------------
/*$sqlquery = "SELECT user_id FROM register WHERE username = '$username' and password =('$password')";
$userIdData = $conn->query($sqlquery);
$rows = $userIdData->fetch_assoc();
$_SESSION['userid'] = $rows['user_id']*/ 	

//----------------------------------------------



/*$user_date = $row['name'];
$user_dayName = $row['dayName'];
$user_startTime = $row['startTime'];
$user_endTime = $row['endTime'];
$user_breakTime = $row['breakTime'];
$user_totalTime = $row['totalTime'];
$user_extraTime = $row['extraTime'];
$user_extraWork = $row['extraWork'];
$user_content = $row['content'];
$user_Wrecord = $row['Wrecord'];
*/

 if(!isset($login_username)){
	 mysql_close($conn);                 //closing connection
	 header('location: login.html');     //redirecting to login page
 }
 
?>